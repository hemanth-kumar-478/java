class Main {
    public static void main(String[] args) {
        AVL tree = new AVL();

        int[] values = {10, 20, 30, 40, 50, 25};
        for (int v : values) {
            tree.root = tree.insert(tree.root, v);
        }

        System.out.print("Inorder traversal: ");
        tree.inorder(tree.root);
        System.out.println();

        System.out.print("Preorder traversal: ");
        tree.preorder(tree.root);
        System.out.println();

        System.out.print("Postorder traversal: ");
        tree.postorder(tree.root);
    }
}

class AVL {
    Node root;

    int height(Node n) {
        return (n == null) ? 0 : n.height;
    }

    int balance(Node n) {
        return (n == null) ? 0 : height(n.llink) - height(n.rlink);
    }

    Node rightRotate(Node y) {
        Node x = y.llink;
        Node t = x.rlink;

        x.rlink = y;
        y.llink = t;

        y.height = Math.max(height(y.llink), height(y.rlink)) + 1;
        x.height = Math.max(height(x.llink), height(x.rlink)) + 1;

        return x;
    }

    Node leftRotate(Node x) {
        Node y = x.rlink;
        Node t = y.llink;

        y.llink = x;
        x.rlink = t;

        x.height = Math.max(height(x.llink), height(x.rlink)) + 1;
        y.height = Math.max(height(y.llink), height(y.rlink)) + 1;

        return y;
    }

    Node insert(Node node, int data) {
        if (node == null)
            return new Node(data);

        if (data < node.data)
            node.llink = insert(node.llink, data);
        else if (data > node.data)
            node.rlink = insert(node.rlink, data);
        else
            return node;

        node.height = Math.max(height(node.llink), height(node.rlink)) + 1;

        int balance = balance(node);

        // LL
        if (balance > 1 && data < node.llink.data)
            return rightRotate(node);

        // RR
        if (balance < -1 && data > node.rlink.data)
            return leftRotate(node);

        // LR
        if (balance > 1 && data > node.llink.data) {
            node.llink = leftRotate(node.llink);
            return rightRotate(node);
        }

        // RL
        if (balance < -1 && data < node.rlink.data) {
            node.rlink = rightRotate(node.rlink);
            return leftRotate(node);
        }

        return node;
    }

    // Inorder traversal
    void inorder(Node node) {
        if (node != null) {
            inorder(node.llink);
            System.out.print(node.data + " ");
            inorder(node.rlink);
        }
    }

    // Preorder traversal
    void preorder(Node node) {
        if (node != null) {
            System.out.print(node.data + " ");
            preorder(node.llink);
            preorder(node.rlink);
        }
    }

    // Postorder traversal
    void postorder(Node node) {
        if (node != null) {
            postorder(node.llink);
            postorder(node.rlink);
            System.out.print(node.data + " ");
        }
    }
}

class Node {
    int data, height;
    Node llink, rlink;

    Node(int data) {
        this.data = data;
        this.height = 1;
    }
}
