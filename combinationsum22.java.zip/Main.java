import java.util.*;
class Main{
    static void solve(int[] arr, int idx, int target, String p) {
        if(target == 0){
            System.out.println(p);
            return;
        }
        for (int i= idx; i < arr.length; i++){
            if (i > idx && arr[i] == arr[i-1]){
                continue;
            }
            if (arr[i] > target) {
                break;
            }
        solve (arr, i+1, target-arr[i], p+arr[i]+" ");
        }
    }
    public static void main (String[] args) {
        int[] arr ={2,3,45,5,8,8,2};
        array.sort(arr);
        solve( arr , 0 , 7 ," " );
    }
}