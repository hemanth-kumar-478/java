class Main{
    public static void main(String [] args){
        int[]a={5, 9 , 3 , 2 , 7 , 6};
        for (int i =0; i < a.length-1 ; i++) {
            int min= i;
            for (int j=i; j<a.length-1; j++){
                if (a[j]<a[min]) {
                    min=j;
                }
                int temp=a[i];
                a[i]=a[min];
                a[min]=temp;
            }
        }
        for (int b:a){
            System.out.println(b);
        }
    }
}