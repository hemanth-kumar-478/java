class Main{
    static int Fact(int n, int result) {
        if (n == 0)
        return result;
        return Fact(n-1,result * n);
    }
    public static void main (String[] args) {
        System.out.println(Fact(5,1));
    }
}